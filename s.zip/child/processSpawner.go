package child

import (
	"fmt"
	"os/exec"
)

type CommandoInfo struct {
	Write        string
	ThreadNumber int
}

type Process interface {
	SpawnProcess()
}

func (c CommandoInfo) SpawnProcess() {
	defer fmt.Printf("Process[%d] ended\n", c.ThreadNumber)
	cmd := exec.Command(c.Write)

	fmt.Printf("Process[%d] getting spawned\n", c.ThreadNumber)
	err := cmd.Run()
	if err != nil {
		fmt.Println("ERR: %s", err.Error())
		fmt.Printf("Process[%d] failed to spawn\n", c.ThreadNumber)
		return
	}
}
